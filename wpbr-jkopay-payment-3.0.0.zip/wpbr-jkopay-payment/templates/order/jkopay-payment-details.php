<?php
/**
 *
 * JKOPay Payment Details template
 *
 * @since 1.0.0
 * @package jkopay
 */

use WPBrewer\JKOPay\Payment\Gateways\JKOPayOrderStatus;
use WPBrewer\JKOPay\Payment\Utils\OrderMeta;

	defined( 'ABSPATH' ) || exit;

?>

<h2><?php echo esc_html__( 'JKOPay Payment Detail', 'wpbr-jkopay-payment' ); ?> </h2>
<div><?php echo esc_html__( 'If no data displayed bellow, please wait and reload the page', 'wpbr-jkopay-payment' ); ?> </div>
<table class="shop_table jkopay_payment_details"><tbody>

<tr><td><strong><?php echo esc_html__( 'Transaction No', 'wpbr-jkopay-payment' ); ?> </strong></td>
<td><?php echo esc_html( $order->get_meta( OrderMeta::TRADE_NO ) ); ?> </td></tr>

<?php
$status_code = $order->get_meta( OrderMeta::STATUS );
$status_desc = JKOPayOrderStatus::get_desc( $status_code );
$state       = '';
if ( empty( $status_desc ) ) {
	$state = $status_code;
} else {
	$state = $status_code . '(' . $status_desc . ')';
}
?>
<tr><td><strong><?php echo esc_html__( 'Transaction Status', 'wpbr-jkopay-payment' ); ?> </strong></td>
<td><?php echo esc_html( $state ); ?> </td></tr>

<tr><td><strong><?php echo esc_html__( 'Transaction Time', 'wpbr-jkopay-payment' ); ?> </strong></td>
<td><?php echo esc_html( $order->get_meta( OrderMeta::TRANS_TIME ) ); ?> </td></tr>


</tbody></table>
