<?php

/**
 *
 * @since             1.0.0
 * @package           jkopay
 *
 * @wordpress-plugin
 * Plugin Name:       JKOPay Payment for WooCommerce
 * Description:       JKOPay Payment for WooCommerce
 * Version:           3.0.0
 * Plugin URI:        https://wpbrewer.com/wpbr-jkopay-payment
 * Author:            WPBrewer
 * Author URI:        https://wpbrewer.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wpbr-jkopay-payment
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

define( 'JKOPAY_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'JKOPAY_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'JKOPAY_BASENAME', plugin_basename( __FILE__ ) );
define( 'JKOPAY_TEMPLATE_DIR', plugin_dir_path( __FILE__ ) . '/templates/' );
define( 'JKOPAY_VERSION', '3.0.0' );

// Load Composer autoloader
if ( file_exists( plugin_dir_path( __FILE__ ) . 'vendor/autoload.php' ) ) {
	require_once plugin_dir_path( __FILE__ ) . 'vendor/autoload.php';
}

/**
 * Declare compatibility with WooCommerce Custom Order Tables.
 *
 * @return void
 */
add_action(
	'before_woocommerce_init',
	function () {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		}
	}
);

/**
 * Display message if WooCommerce is not activated.
 *
 * @return void
 */
function jkopay_needs_woocommerce() {
	echo '<div id="message" class="error">';
	echo '  <p>' . esc_html__( 'JKOPay needs WooCommerce, please intall and activate WooCommerce first!', 'wpbr-jkopay-payment' ) . '</p>';
	echo '</div>';
}

/**
 * Execute JKOPay Payment
 *
 * @return void
 */
function run_jkopay_payment() {

	if ( ! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		if ( is_plugin_active( 'wpbr-jkopay-payment/wpbr-jkopay-payment.php' ) ) {
			deactivate_plugins( plugin_basename( __FILE__ ) );
			add_action( 'admin_notices', 'jkopay_needs_woocommerce' );
			return;
		}
	}

	// Initialize the plugin using the autoloaded class
	\WPBrewer\JKOPay\Payment\JKOPayPayment::init();
}
add_action( 'plugins_loaded', __NAMESPACE__ . '\run_jkopay_payment' );
