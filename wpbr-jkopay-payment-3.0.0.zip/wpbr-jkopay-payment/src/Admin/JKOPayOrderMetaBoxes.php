<?php

namespace WPBrewer\JKOPay\Payment\Admin;

use Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController;
use WPBrewer\JKOPay\Payment\Gateways\JKOPayOrderStatus;
use WPBrewer\JKOPay\Payment\Gateways\JKOPayPaymentSubscription;
use WPBrewer\JKOPay\Payment\JKOPayPayment;
use WPBrewer\JKOPay\Payment\Utils\OrderMeta;
use WPBrewer\JKOPay\Payment\Utils\SingletonTrait;

defined( 'ABSPATH' ) || exit;

/**
 * JKOPayOrderMetaBoxes class
 */
class JKOPayOrderMetaBoxes {

	use SingletonTrait;
	/**
	 * Init the class
	 *
	 * @return void
	 */
	public static function init() {
		self::get_instance();

		add_action( 'add_meta_boxes', array( self::get_instance(), 'jkopay_add_meta_boxes' ), 10, 2 );

	}

	/**
	 * Add admin meta box
	 *
	 * @param object $post The post object.
	 * @return void
	 */
	public function jkopay_add_meta_boxes( $post_type, $post_or_order_object ) {
		
		$order = ( $post_or_order_object instanceof \WP_Post ) ? wc_get_order( $post_or_order_object->ID ) : $post_or_order_object;

		if ( ! $order instanceof \WC_Order ) {
			return;
		}

		if ( ! array_key_exists( $order->get_payment_method(), JKOPayPayment::$allowed_payments ) ) {
			return;
		}

		// Get the appropriate screen ID based on whether we're using HPOS or not
		$screen = wc_get_container()->get( CustomOrdersTableController::class )->custom_orders_table_usage_is_enabled()
		? wc_get_page_screen_id( 'shop-order' )
		: 'shop_order';

		// Add meta box to regular orders
		add_meta_box(
			'woocommerce-jkopay-meta-boxes',
			__( 'JKOPay Payment Details', 'wpbr-jkopay-payment' ),
			array(
				self::get_instance(),
				'jkopay_admin_meta',
			),
			$screen,
			'side',
			'default'
		);

		// Add meta box to subscription orders
		$subscription_screen = wc_get_container()->get( CustomOrdersTableController::class )->custom_orders_table_usage_is_enabled()
		? wc_get_page_screen_id( 'shop-subscription' )
		: 'shop_subscription';

		add_meta_box(
			'woocommerce-jkopay-meta-boxes',
			__( 'JKOPay Payment Details', 'wpbr-jkopay-payment' ),
			array(
				self::get_instance(),
				'jkopay_admin_meta_subscription',
			),
			$subscription_screen,
			'side',
			'default'
		);
	}


	/**
	 * Display metabox
	 *
	 * @param object $post_or_order_object Post object.
	 * @return void
	 */
	public function jkopay_admin_meta( $post_or_order_object ) {

		$order = ( $post_or_order_object instanceof \WP_Post ) ? wc_get_order( $post_or_order_object->ID ) : $post_or_order_object;

		if ( ! $order ) {
			return;
		}

		echo '<table>';

		echo '<tr><td>' . esc_html__( 'Transaction No', 'wpbr-jkopay-payment' ) . '</td><td>' . esc_html( $order->get_meta( OrderMeta::TRADE_NO ) ) . '</td></tr>';
		echo '<tr><td>' . esc_html__( 'Platform Order ID', 'wpbr-jkopay-payment' ) . '</td><td>' . esc_html( $order->get_meta( OrderMeta::PLATFORM_ORDER_ID ) ) . '</td></tr>';
		
		if ( $order->get_payment_method() === JKOPayPaymentSubscription::GATEWAY_ID ) {
			$auth_no = $order->get_meta( OrderMeta::AUTH_NO );
			echo '<tr><td>' . esc_html__( 'Auth No', 'wpbr-jkopay-payment' ) . '</td><td>' . esc_html( $auth_no ) . '</td></tr>';
			$auth_status = $order->get_meta( OrderMeta::AUTH_STATUS );
			echo '<tr><td>' . esc_html__( 'Auth Status', 'wpbr-jkopay-payment' ) . '</td><td>' . esc_html( $auth_status ) . '</td></tr>';
		}
			
		$status_code = $order->get_meta( OrderMeta::STATUS );
		$status_desc = JKOPayOrderStatus::get_desc( $status_code );
		if ( empty( $status_desc ) ) {
			$status = $status_code;
		} else {
			$status = $status_code . '(' . $status_desc . ')';
		}
		echo '<tr><td>' . esc_html__( 'Transaction Status', 'wpbr-jkopay-payment' ) . '</td><td>' . esc_html( $status ) . '</td></tr>';
		echo '<tr><td>' . esc_html__( 'Transaction Time', 'wpbr-jkopay-payment' ) . '</td><td>' . esc_html( $order->get_meta( OrderMeta::TRANS_TIME ) ) . '</td></tr>';
		// echo '<tr><td>' . esc_html__( 'API Mode', 'wpbr-jkopay-payment' ) . '</td><td>' . esc_html( $order->get_meta( OrderMeta::REQUEST_MODE ) ) . '</td></tr>';

		echo '</table>';
	}

	public function jkopay_admin_meta_subscription( $post_or_order_object ) {
		$order = ( $post_or_order_object instanceof \WP_Post ) ? wc_get_order( $post_or_order_object->ID ) : $post_or_order_object;

		if ( ! $order ) {
			return;
		}

		if ( $order->get_payment_method() === JKOPayPaymentSubscription::GATEWAY_ID ) {
		    echo '<table>';
			$auth_no = $order->get_meta( OrderMeta::AUTH_NO );
			echo '<tr><td>' . esc_html__( 'Auth No', 'wpbr-jkopay-payment' ) . '</td><td>' . esc_html( $auth_no ) . '</td></tr>';
			$auth_status = $order->get_meta( OrderMeta::AUTH_STATUS );
			echo '<tr><td>' . esc_html__( 'Auth Status', 'wpbr-jkopay-payment' ) . '</td><td>' . esc_html( $auth_status ) . '</td></tr>';
		    echo '</table>';
		}
	}

}
