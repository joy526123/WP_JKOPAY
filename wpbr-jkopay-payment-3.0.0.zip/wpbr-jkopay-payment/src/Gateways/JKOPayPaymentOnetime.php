<?php

namespace WPBrewer\JKOPay\Payment\Gateways;
/**
 * JKOPayPaymentOnetime class file
 *
 * @package jkopay
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * JKOPay Payment Gateway
 *
 * @class JKOPayPaymentOnetime
 * @extends WC_Payment_Gateway
 *
 * @version 1.0.0
 */
class JKOPayPaymentOnetime extends \WC_Payment_Gateway {

	const GATEWAY_ID = 'jkopay-payment-onetime';

	public $payment_type;

	public $authpay_result_display_url;

	public $authpay_result_url;

	/**
	 * The constructor.
	 */
	public function __construct() {

		$this->id                 = self::GATEWAY_ID;
		$this->icon               = $this->get_icon();
		$this->title              = $this->get_option( 'title' );
		$this->description        = $this->get_option( 'description' );
		$this->has_fields         = false;
		$this->order_button_text  = __( 'Pay with JKOPay', 'wpbr-jkopay-payment' );
		$this->method_title       = __( 'JKOPay - One Time', 'wpbr-jkopay-payment' );
		$this->method_description = __( 'Pay via JKOPay', 'wpbr-jkopay-payment' );

		$this->payment_type = 'limited';

		$this->authpay_result_display_url = WC()->api_request_url( 'jkopay_authpay_result_display' );
		$this->authpay_result_url         = WC()->api_request_url( 'jkopay_authpay_result' );

		// Support refund function.
		$this->supports = array(
			'products',
			'refunds',
		);

		// Define form field to show in admin setting.
		$this->init_form_fields();
		$this->init_settings();

		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		add_filter( 'woocommerce_thankyou_order_received_text', array( $this, 'thankyou_order_on_hold_message' ), 10, 2 );
		add_action( 'woocommerce_order_details_before_order_table', array( $this, 'display_on_hold_message_on_order_details' ) );
		add_action( 'woocommerce_order_details_after_order_table', array( $this, 'jkopay_payment_detail_after_order_table' ), 10, 1 );

	}

	/**
	 * Payment gateway icon output
	 *
	 * @return string
	 */
	public function get_icon() {

		$icon_html = '';
		if ( get_option( 'jkopay_payment_display_logo_enabled' ) === 'yes' ) {
			$logo_type = get_option( 'jkopay_payment_logo_type' );
			if ( 'black' === $logo_type ) {
				$icon_html .= '<img src="' . JKOPAY_PLUGIN_URL . 'assets/images/jkopay-logo-black.svg" alt="' . __( 'JKOPay', 'wpbr-jkopay-payment' ) . '" />';
			} else {
				$icon_html .= '<img src="' . JKOPAY_PLUGIN_URL . 'assets/images/jkopay-logo-white.svg" alt="' . __( 'JKOPay', 'wpbr-jkopay-payment' ) . '" />';
			}
		}
		/**
		 * Allow to filter the payment gateway icon.
		 *
		 * @since 1.0.0
		 *
		 * @param string $icon_html The payment gateway icon HTML.
		 * @param string $this->id  The payment gateway id.
		 */
		return apply_filters( 'woocommerce_gateway_icon', $icon_html, $this->id );

	}

	/**
	 * Form fields Initialize the information.
	 *
	 * @see WC_Settings_API::init_form_fields()
	 */
	public function init_form_fields() {
		$this->form_fields = include JKOPAY_PLUGIN_DIR . 'includes/settings/settings-jkopay-payment-onetime.php';
	}

	/**
	 * Process payments and return results.
	 * return the success and redirect in an array. e.g:
	 * return array(
	 *    'result'   => 'success',
	 *    'redirect' => $this->get_return_url( $order )
	 * );
	 *
	 * @param int $order_id Order ID.
	 * @return array
	 */
	public function process_payment( $order_id ) {

		// TODO: should I emtpy cart here?
		WC()->cart->empty_cart();

		$jkopay_request = new JKOPayPaymentRequest( $this );
		return $jkopay_request->authpay_create( $order_id );
	}

	/**
	 * Process the refund and return the result.
	 *
	 * @param int    $order_id The order id.
	 * @param float  $amount The ammount to be refund.
	 * @param string $reason The reason why the refund is requested.
	 *
	 * @return bool|WP_Error
	 */
	public function process_refund( $order_id, $amount = null, $reason = '' ) {
		$jkopay_request = new JKOPayPaymentRequest( $this );
		return $jkopay_request->refund( $order_id, $amount, $reason );
	}

	/**
	 * Check if the gateway is available for use.
	 *
	 * @return bool
	 */
	public function is_available() {
		$is_available = ( 'yes' === $this->enabled );

		return $is_available;
	}

	/**
	 * Display message on thank you page when order status is on-hold or pending.
	 *
	 * @param string   $text Text display on thank you page.
	 * @param WC_Order $order The order object.
	 *
	 * @return string
	 */
	public function thankyou_order_on_hold_message( $text, $order ) {

		if ( $order ) {
			if ( $order->get_payment_method() !== $this->id ) {
				return $text;
			}

			if ( $order->get_status() === 'on-hold' ) {
				$text = '<span class="jkopay-order-onhold">' . esc_html__( 'We have received your order, but the payment status need to be confirmed. Please contact the support.', 'wpbr-jkopay-payment' ) . '</span>';
			}

			if ( $order->get_status() === 'pending' ) {
				$text = '<span class="jkopay-order-onhold">' . esc_html__( 'We have received your order, but the order is awaiting payment. Please pay again.', 'wpbr-jkopay-payment' ) . '</span>';
			}
		}

		return $text;
	}

	/**
	 * Display the message on the order details page when order status is on-hold or pending.
	 *
	 * @param WC_Order $order Order object.
	 */
	public function display_on_hold_message_on_order_details( $order ) {

		if ( is_checkout() ) {
			return;
		}
		if ( $order->get_payment_method() !== $this->id ) {
			return;
		}

		if ( $order->get_status() === 'on-hold' ) {
			echo '<div class="jkopay-order-onhold">' . esc_html__( 'We have received your order, but the payment status need to be confirmed. Please contact the support.', 'wpbr-jkopay-payment' ) . '</div>';
		}

		if ( $order->get_status() === 'pending' ) {
			echo '<div class="jkopay-order-onhold">' . esc_html__( 'We have received your order, but the order is awaiting payment. Please pay again.', 'wpbr-jkopay-payment' ) . '</div>';
		}

	}

	public function jkopay_payment_detail_after_order_table( $order ) {

		if ( $order->get_payment_method() === $this->id ) {
			wc_get_template( 'order/jkopay-payment-details.php', array( 'order' => $order ), '', JKOPAY_TEMPLATE_DIR );
		}

	}


}
