<?php

namespace WPBrewer\JKOPay\Payment\Gateways;

use WPBrewer\JKOPay\Payment\JKOPayPayment;
use WPBrewer\JKOPay\Payment\Utils\AuthStatus;
use WPBrewer\JKOPay\Payment\Utils\OrderMeta;
use WPBrewer\JKOPay\Payment\Utils\SingletonTrait;

/**
 * JKOPay Subscriptions Handler class
 *
 * @package jkopay
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * JKOPay Subscriptions Handler
 *
 * @class JKOPayPaymentSubscriptionsHandler
 *
 * @version 1.0.0
 */
class JKOPayPaymentSubscriptionsHandler {
	
	use SingletonTrait;

	/**
	 * Initialize class and add hooks
	 *
	 * @return void
	 */
	public static function init() {
		$class = self::get_instance();
	
		add_action( 'woocommerce_subscription_renewal_payment_failed', array( $class, 'subscription_fail_handler' ), 99, 2 );
		
		// 續訂訂單付款
		add_action( 'woocommerce_scheduled_subscription_payment_'.JKOPayPaymentSubscription::GATEWAY_ID, array( $class, 'process_subscription_payment' ), 10, 2 );
		
		add_filter( 'woocommerce_available_payment_gateways', array( $class, 'conditional_payment_gateways' ), 10, 1 );

		// 訂閱取消時，取消街口授權
		add_action( 'woocommerce_subscription_status_cancelled', array( $class, 'cancel_authpay_when_subscription_cancelled' ), 10, 1 );
		// add_action( 'woocommerce_subscription_cancelled_' . JKOPayPaymentSubscription::GATEWAY_ID, array( $class, 'cancel_authpay_when_subscription_cancelled' ), 10, 2 );
	}

	/**
	 * Process subscription payment
	 *
	 * @param int      $amount The amount.
	 * @param WC_Order $order  The order object.
	 *
	 * @return bool|WP_Error
	 */
	public static function process_subscription_payment( int $amount, \WC_Order $order ) {

		$request = new JKOPayPaymentRequest( new JKOPayPaymentSubscription() );

		$result = $request->authpay_request( $order );
		JKOPayPayment::log( 'authpay_transaction result:' . wc_print_r( $result, true ) );

		if (  is_wp_error( $result ) ) {
			$order->add_order_note( sprintf( __( 'JKOPay subscription payment failed. Error: %s', 'wpbr-jkopay-payment' ), $result->get_error_message() ) );
			return $result;
		}

		if ( '000' === $result->result ) {
			$order->payment_complete( $result->result_object->tradeNo );

			$order->update_meta_data( OrderMeta::TRADE_NO, $result->result_object->tradeNo );
			$order->update_meta_data( OrderMeta::STATUS, $result->result_object->status );
			$order->update_meta_data( OrderMeta::TRANS_TIME, $result->result_object->trans_time );
		} elseif ( '302' === $result->result ) {
			$order->update_meta_data( OrderMeta::AUTH_STATUS, AuthStatus::CANCEL );
			$order->add_order_note( sprintf( __( 'JKOPay subscription payment failed. Result Message: %s', 'wpbr-jkopay-payment' ), $result->message ) );
		}

		$order->save();
		return true;
	}

	/**
	 * 當購物車中有訂閱商品時，只顯示訂閱付款方式。若購物車中無訂閱商品，則隱藏訂閱付款方式。
	 *
	 * @param array $available_gateways The available gateways.
	 */
	public static function conditional_payment_gateways( array $available_gateways ): array {

		if ( is_admin() ) {
			return $available_gateways;
		}

		if ( ! class_exists( 'WC_Subscriptions_Cart' ) || ! function_exists( 'wcs_cart_contains_renewal' ) ) {
			return $available_gateways;
		}

		if ( \WC_Subscriptions_Cart::cart_contains_subscription() || \wcs_cart_contains_renewal() ) {
			
			$subscription_gateways = array();
			foreach ( $available_gateways as $gateway_id => $gateway ) {
				if ( $gateway->supports( 'subscriptions' ) ) {
					$subscription_gateways[$gateway_id] = $gateway;
				}
			}
			return $subscription_gateways;
		 } else {
			if ( isset( $available_gateways['jkopay-payment-subscription'] ) ) {
				unset( $available_gateways['jkopay-payment-subscription'] );
		 	}
		    return $available_gateways;
		}
	}

	public static function cancel_authpay_when_subscription_cancelled( $subscription ) {

		if ( $subscription->get_payment_method() !== JKOPayPaymentSubscription::GATEWAY_ID ) {
			return;
		}
		
		$auth_no     = $subscription->get_meta( OrderMeta::AUTH_NO );
		$auth_status = $subscription->get_meta( OrderMeta::AUTH_STATUS );
		if ( $auth_no && AuthStatus::GRANTED === $auth_status ) {
			$request = new JKOPayPaymentRequest( new JKOPayPaymentSubscription() );
			$request->authpay_cancel( $subscription );
		}
	}

}