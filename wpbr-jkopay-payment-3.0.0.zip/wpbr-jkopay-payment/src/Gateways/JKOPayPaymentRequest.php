<?php

namespace WPBrewer\JKOPay\Payment\Gateways;

use WPBrewer\JKOPay\Payment\JKOPayPayment;
use WPBrewer\JKOPay\Payment\Utils\AuthStatus;
use WPBrewer\JKOPay\Payment\Utils\OrderMeta;

/**
 * JKOPay Payment Request class
 *
 * @package jkopay
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * JKOPay Payment Request
 *
 * @class JKOPayPaymentRequest
 *
 * @version 1.0.0
 */
class JKOPayPaymentRequest {

	/**
	 * The payment gateway instance.
	 *
	 * @var JKOPayPayment
	 */
	private $gateway;

	/**
	 * Constructor.
	 *
	 * @param JKOPayPayment $gateway The payment gateway instance.
	 */
	public function __construct( $gateway ) {
		$this->gateway = $gateway;
	}

	/**
	 * Call JKOPay's entry-api and return the result.
	 * Change the order status according to the api call result.
	 *
	 * Request successful
	 * -post-meta fixes
	 *
	 * Request failed
	 * -fix order_status
	 *
	 * @param int $order_id Order ID.
	 * @return array
	 */
	public function request( $order_id ) {

		try {

			$order    = wc_get_order( $order_id );
			$order_id = $order->get_id();
			$currency = $order->get_currency();

			$std_amount = $order->get_total();

			$body = array(
				'platform_order_id'  => self::build_platform_order_id( $order ),
				'store_id'           => get_option( 'jkopay_payment_storeid' ),
				'currency'           => $currency,
				'total_price'        => $std_amount,
				'final_price'        => $std_amount,
				'unredeem'           => 0,
				'confirm_url'        => $this->gateway->confirm_url,
				'result_url'         => $this->gateway->result_url,
				'result_display_url' => self::get_return_url( $order ),
				'payment_type'       => $this->gateway->payment_type,
			);

			$request_args = $this->build_execute_request_args( $body );
			JKOPayPayment::log( sprintf( '[entry][platform_order_id:%s] execute request_args: %s', $body['platform_order_id'], wc_print_r( $request_args, true ) ) );

			$result = $this->execute( 'entry', $request_args );
			JKOPayPayment::log( 'request result:' . wc_print_r( $result, true ) );
			// phpcs:disable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			if ( '000' !== $result->result ) {
				throw new \Exception( sprintf( 'Execute JKOPay Entry request API failed. Return code: %s. Response body: %s', $result->result, wc_print_r( $result, true ) ) );
			}

			$order->update_meta_data( OrderMeta::PLATFORM_ORDER_ID, $body['platform_order_id'] );
			$order->save();

			// 回傳 paymentUrl 導向 JKOPay 付款頁面.
			return array(
				'result'   => 'success',
				'redirect' => $result->result_object->payment_url,
			);

		} catch ( \Exception $e ) {

			JKOPayPayment::log( 'process payment request error:' . $e->getMessage(), 'error' );

			wc_add_wp_error_notices( new \WP_Error( 'process_payment_request', __( '[JKOPay] Order Received but unable to process payment request. Please try to pay again.', 'wpbr-jkopay-payment' ) ) );

			// 回傳導向 checkout order pay 頁面.
			return array(
				'result'   => 'success',
				'redirect' => $order->get_checkout_payment_url( false ),
			);

		}
	}

	/**
	 * 建立授權綁定(非實際扣款)
	 */
	public function authpay_create( $order_id ) {
		try {

			$order    = wc_get_order( $order_id );

			$body = array(
				'authpay_name'       => 'Order#' . $order->get_id() . '-' . $this->get_subscription_items_name( $order ),
				'platform_authpay_id'  => self::build_platform_order_id( $order ),
				'store_id'           => get_option( 'jkopay_payment_storeid' ),
				'cancelable'         => true,
				'result_url'         => $this->gateway->authpay_result_url,
				'result_display_url' => add_query_arg( array( 'order_id' => $order->get_id() ), $this->gateway->authpay_result_display_url ),
			);

			$request_args = $this->build_execute_request_args( $body );
			JKOPayPayment::log( sprintf( '[authpay][platform_order_id:%s] execute request_args: %s', $body['platform_authpay_id'], wc_print_r( $request_args, true ) ) );

			$result = $this->execute( 'authpay_create', $request_args );
			JKOPayPayment::log( 'authpay_create result:' . wc_print_r( $result, true ) );
			// phpcs:disable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			if ( '000' !== $result->result ) {
				throw new \Exception( sprintf( 'Execute JKOPay Authpay Create request API failed. Return code: %s. Response body: %s', $result->result, wc_print_r( $result, true ) ) );
			}

			$order->update_meta_data( OrderMeta::PLATFORM_ORDER_ID, $body['platform_authpay_id'] );
			$order->update_meta_data( OrderMeta::AUTH_NO, $result->result_object->auth_no );
			$order->save();

			// 回傳 paymentUrl 導向 JKOPay 付款頁面.
			return array(
				'result'   => 'success',
				'redirect' => $result->result_object->authpay_url,
			);

		} catch ( \Exception $e ) {

			JKOPayPayment::log( 'process payment request error:' . $e->getMessage(), 'error' );

			wc_add_wp_error_notices( new \WP_Error( 'process_payment_request', __( '[JKOPay] Order Received but unable to process payment request. Please try to pay again.', 'wpbr-jkopay-payment' ) ) );

			// 回傳導向 checkout order pay 頁面.
			return array(
				'result'   => 'success',
				'redirect' => $order->get_checkout_payment_url( false ),
			);

		}
	}

	/**
	 * 
	 * @param int $order_id
	 * @return object|WP_Error
	 */
	public function authpay_request( $order_id ) {

		$order = wc_get_order( $order_id );
		
		if ( $order && $order->needs_payment() ) {
		
			$auth_no = $order->get_meta( OrderMeta::AUTH_NO );
			$status  = $order->get_meta( OrderMeta::AUTH_STATUS );
			JKOPayPayment::log( 'order_id: ' . $order->get_id() . ' auth_no: ' . $auth_no . ' status: ' . $status );
			
			if ( $auth_no && AuthStatus::GRANTED === $status ) {
			
				$body = array(
					'auth_no'       => $auth_no,
					'order' => array(
						'platform_order_id' => self::build_platform_order_id( $order ),
						'trade_name'        => substr('Order#' . $order->get_id() . '-' . $this->get_subscription_items_name( $order ), 0, 30),
						'currency'          => 'TWD', 
						'total_price'       => $order->get_total(),
						'final_price'       => $order->get_total(),
					)
				);

				$order->update_meta_data( OrderMeta::PLATFORM_ORDER_ID, $body['order']['platform_order_id'] );
				$order->save();
	
				$request_args = $this->build_execute_request_args( $body );
				JKOPayPayment::log( sprintf( '[authpay][platform_order_id:%s] execute request_args: %s', $body['order']['platform_order_id'], wc_print_r( $request_args, true ) ) );
	
				$result = $this->execute( 'authpay_transaction', $request_args );
				JKOPayPayment::log( 'authpay_transaction result:' . wc_print_r( $result, true ) );
				// phpcs:disable WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase

				return $result;
			} else {
				return new \WP_Error( 'authpay_request', __( '[JKOPay] No auth_no or auth_status is not granted.', 'wpbr-jkopay-payment' ) );
			}
		}
	}

	public function authpay_cancel( $subscription ) {
		$auth_no = $subscription->get_meta( OrderMeta::AUTH_NO );
		$body = array(
			'auth_no' => $auth_no,
		);

		$request_args = $this->build_execute_request_args( $body );
		JKOPayPayment::log( sprintf( '[authpay_cancel][auth_no:%s] execute request_args: %s', $auth_no, wc_print_r( $request_args, true ) ) );

		$result = $this->execute( 'authpay_cancel', $request_args );
		JKOPayPayment::log( 'authpay_cancel result:' . wc_print_r( $result, true ) );

		if ( '000' === $result->result ) { 
			JKOPayPayment::log( 'authpay_cancel success for subscription: ' . $subscription->get_id() );
			$subscription->add_order_note( sprintf( __( 'Auth No: %s canceled for subscription: %s', 'wpbr-jkopay-payment' ), $auth_no, $subscription->get_id() ) );
			$subscription->update_meta_data( OrderMeta::AUTH_STATUS, AuthStatus::CANCEL );
			$subscription->save();
		} else {
			JKOPayPayment::log( 'authpay_cancel failed for subscription: ' . $subscription->get_id() );
			$subscription->add_order_note( sprintf( __( 'Auth No: %s cancel failed. Message: %s', 'wpbr-jkopay-payment' ), $auth_no, $result->message ) );
		}
	}

	/**
	 * Request JKOPay's refund-api and return the result.
	 *
	 * @param int    $order_id The order id.
	 * @param string $refund_amount => wc_format_decimal().
	 * @param string $reason The reason of refund.
	 *
	 * @return boolean(true)|WP_Error
	 */
	public function refund( $order_id, $refund_amount, $reason = '' ) {

		$order = wc_get_order( $order_id );

		if ( false === $order ) {

			return new \WP_Error(
				'process_refund_request',
				sprintf( __( 'Unable to find order #%s', 'wpbr-jkopay-payment' ), $order_id ),
				array(
					'order_id'      => $order_id,
					'refund_amount' => $refund_amount,
				)
			);

		}

		$transaction_id = $order->get_transaction_id();
		$result         = $this->do_refund( $order, $transaction_id, $refund_amount );

		return $result;
	}

	/**
	 * Build request arguments for JKOPay API.
	 *
	 * @param string $url The request url.
	 * @param array  $body The request body.
	 * @param int    $timeout The request timeout.
	 * @param string $method The request method.
	 *
	 * @return array
	 */
	private function build_execute_request_args( $body = null, $timeout = 20, $method = 'POST' ) {

		$secret_key = get_option( 'jkopay_payment_secret_key' );
		$api_key    = get_option( 'jkopay_payment_api_key' );

		$request_body = '';
		if ( ! is_null( $body ) ) {
			if ( is_array( $body ) ) {
				$request_body = wp_json_encode( $body );
			} else {
				$request_body = $body;
			}
		}

		$headers = array(
			'content-type' => 'application/json; charset=UTF-8',
			'Api-Key'      => $api_key,
			'Digest'       => self::generate_signature( $secret_key, $request_body ),
		);

		$request_args = array(
			'httpversion' => '1.1',
			'timeout'     => $timeout,
			'headers'     => $headers,
			'method'      => $method,
		);

		if ( is_array( $body ) ) {
			$request_args = array_merge( $request_args, array( 'body' => wp_json_encode( $body ) ) );
		}

		return $request_args;
	}

	/**
	 * Call the refund API and store the information DB according to the result.
	 * 1. Save refund information in the form of serialized array
	 * 2. After refund, the balance of the transaction amount is stored in string form.
	 *
	 * @param WC_Order      $order The order object.
	 * @param string        $transaction_id The transaction id of the order.
	 * @param number|string $refund_amount The refund amount.
	 * @param boolean       $is_partial_refund Whether the refund is partial or fully.
	 *
	 * @return boolean(true)|WP_Error
	 */
	private function do_refund( $order, $transaction_id, $refund_amount ) {

		$platform_order_id = self::get_platform_order_id( $order );

		$body = array(
			'platform_order_id' => $platform_order_id,
			'refund_amount'     => $refund_amount,
		);

		$request_args = $this->build_execute_request_args( $body );
		JKOPayPayment::log( sprintf( '[refund][platform_order_id:%s] request_args:%s', $platform_order_id, wc_print_r( $request_args, true ) ) );

		try {
			$resp = $this->execute( 'refund', $request_args );

			if ( '000' !== $resp->result ) {
				throw new \Exception( sprintf( 'Execute JKOPay Refund API failed. Return code: %s. Response body: %s', $resp->result, wc_print_r( $resp ) ) );
			}
		} catch ( \Exception $e ) {
			JKOPayPayment::log( sprintf( '[refund][platform_order_id:%s] refund error:%s', $platform_order_id, $e->getMessage() ) );
			return new \WP_Error( $e->getMessage() );
		}

		if ( '000' === $resp->result ) {

			// get meta always return '' or array().
			$refund_ids = $order->get_meta( OrderMeta::REFUND_TRANSACTION_IDS );
			if ( empty( $refund_ids ) ) {
				$refund_ids = array();
			}

			$refund_ids[] = $resp->result_object->refund_tradeNo;
			JKOPayPayment::log( sprintf( '[refund][platform_order_id:%s] refund tradeNo:%s', $platform_order_id, wc_print_r( $refund_ids, true ) ) );

			$order->update_meta_data( OrderMeta::REFUND_TRANSACTION_IDS, $refund_ids );
			$order->save();

			$order->add_order_note( sprintf( __( 'Refund via JKOPay successfully. Refund tradeNo: %s', 'wpbr-jkopay-payment' ), $resp->result_object->refund_tradeNo ) );

		} else {
			$order->add_order_note( sprintf( __( 'Refund via JKOPay failed. Refund tradeNo: %1$s, result: %2$s, message: %3$s', 'wpbr-jkopay-payment' ), $resp->refund_tradeNo, $resp->result, $resp->message ) );
		}

		return true;
	}

	/**
	 * Sends a request based on the transmitted information and returns the result.
	 * When requesting JKOPay, create a header to be used in common.
	 *
	 * @param string $url The API URL.
	 * @param array  $request_args The request arguments.
	 * @param int    $timeout Timeout in seconds.
	 * @return mixed|WP_Error Return respond body or WP_Error
	 *
	 * @throws Exception When the request failed.
	 */
	private function execute( $request_type, $request_args = null, $timeout = 20 ) {

		$api_relay_enabled = get_option( 'jkopay_payment_api_relay_enabled' );
		if ( wc_string_to_bool( $api_relay_enabled ) ) {
			$url = 'https://api.wpbrewer.com/wp-json/jkopay/v1/' . $request_type;
		} else {
			$url = $this->get_request_url( $request_type );
		}

		JKOPayPayment::log( 'api_relay_enabled: ' . $api_relay_enabled );
		JKOPayPayment::log( 'executeurl: ' . $url );

		$response = wp_remote_request( $url, $request_args );

		if ( is_wp_error( $response ) ) {
			throw new \Exception( 'Execute remote request error:' . $response->get_error_message() );
		}

		$http_status   = (int) $response['response']['code'];
		$response_body = self::json_custom_decode( wp_remote_retrieve_body( $response ) );
		$return_code   = $response_body->returnCode;

		JKOPayPayment::log( '[execute] http response code: ' . $http_status . ', response body: ' . wc_print_r( $response_body, true ) );

		if ( 200 !== $http_status ) {
			throw new \Exception( sprintf( 'Execute API http response not success. http response code: %s. url: %s', $http_status, $url ) );
		}

		return $response_body;
	}

	private function get_subscription_items_name( $order ) {
		// if ( function_exists( 'wcs_order_contains_subscription' ) && wcs_order_contains_subscription( $order ) ) {
			// JKOPay_Payment::log( 'order_contains_subscription: ' . $order->get_id() );
			$subscription_items = array();
			$items = $order->get_items();
			foreach ( $items as $item ) {
				$product = $item->get_product();
				$name = $product->get_name();
				$subscription_items[] = $name;
			}
			return implode( ', ', $subscription_items );
		// } else {
		// 	JKOPay_Payment::log( 'order_not_contains_subscription: ' . $order->get_id() );
		// 	return '';
		// }
	}

	/**
	 * Returns the URL that matches the request type.
	 *
	 * @param string $type The request type.
	 * @param array  $args The request arguments.
	 * @return string
	 */
	private function get_request_url( $type, $args = array() ) {
		$host = $this->get_request_host();
		$uri  = $this->get_request_uri( $type, $args );

		return $host . $uri;
	}

	/**
	 * Returns HOST information that matches the environmental information of JKOPay Gateway.
	 *
	 * @return string
	 */
	private function get_request_host() {

		if ( JKOPayPayment::$testmode ) {
			return 'https://uat-onlinepay.jkopay.app';
		} else {
			return 'https://onlinepay.jkopay.com';
		}

	}

	/**
	 * Returns the uri that matches the request type.
	 * If the uri contains variables, it is combined with args to create a new uri.
	 *
	 * @param string $type The request type.
	 * @param array  $args The request arguments.
	 * @return string
	 */
	private function get_request_uri( $type, $args ) {
		$uri = '';

		switch ( $type ) {
			case 'entry':
				$uri = '/platform/entry';
				break;
			case 'refund':
				$uri = '/platform/refund';
				break;
			case 'inquiry':
				$uri = '/platform/inquiry';
				break;
			case 'authpay_create':
				$uri = '/platform/authpay/limited';
				break;
			case 'authpay_inquiry':
				$uri = '/platform/authpay/detail';
				break;
			case 'authpay_cancel':
				$uri = '/platform/authpay/cancel';
				break;
			case 'authpay_transaction':
				$uri = '/platform/authpay/transaction';
				break;
		}

		$new_uri = $uri;
		// foreach ( $args as $key => $value ) {
		// $new_uri = str_replace( '{' . $key . '}', $value, $new_uri );
		// }

		return $new_uri;
	}

	/**
	 * Get the return url (thank you page).
	 *
	 * @param WC_Order|null $order Order object.
	 * @return string
	 */
	public static function get_return_url( $order = null ) {
		if ( $order ) {
			$return_url = $order->get_checkout_order_received_url();
		} else {
			$return_url = wc_get_endpoint_url( 'order-received', '', wc_get_checkout_url() );
		}

		return apply_filters( 'woocommerce_get_return_url', $return_url, $order );
	}

	/**
	 * Hange large integer to json's string format.
	 *
	 * @param String $json The json string.
	 * @return mixed
	 */
	private static function json_custom_decode( $json ) {
		if ( version_compare( PHP_VERSION, '5.4.0', '>=' ) ) {
			return json_decode( $json, false, 512, JSON_BIGINT_AS_STRING );
		} else {
			return json_decode( preg_replace( '/:\s?(\d{14,})/', ': "${1}"', $json ) );
		}
	}

	/**
	 * Generate signature
	 *
	 * @param string $secret_key The secret key.
	 * @param string $request_body The request body.
	 *
	 * @return string
	 */
	private static function generate_signature( $secret_key, $request_body ) {
		return hash_hmac( 'sha256', $request_body, $secret_key );
	}

	public static function build_platform_order_id( $order ) {
		$order_prefix          = get_option( 'jkopay_payment_order_prefix' );
		$order_prefix_verified = get_option( 'jkopay_payment_order_prefix_verified' );
		if ( ! wc_string_to_bool( $order_prefix_verified ) ) {
			JKOPayPayment::log( 'order_prefix_verified: ' . $order_prefix_verified );
			$order_prefix = '';
		}
		return $order_prefix . $order->get_id();
	}

	public static function get_platform_order_id( $order ) {
		$platform_order_id = $order->get_meta( OrderMeta::PLATFORM_ORDER_ID );
		if ( empty( $platform_order_id ) ) {
			$platform_order_id = $order->get_id();
		}
		return apply_filters( 'jkopay_platform_order_id', $platform_order_id );
	}

}
