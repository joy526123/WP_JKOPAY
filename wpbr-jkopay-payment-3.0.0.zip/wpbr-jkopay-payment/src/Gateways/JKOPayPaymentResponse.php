<?php

namespace WPBrewer\JKOPay\Payment\Gateways;

use WPBrewer\JKOPay\Payment\JKOPayPayment;
use WPBrewer\JKOPay\Payment\Utils\OrderMeta;
use WPBrewer\JKOPay\Payment\Utils\SingletonTrait;

/**
 * JKOPay Payment Response class
 *
 * @package jkopay
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * JKOPay Payment Response
 *
 * @class JKOPayPaymentResponse
 *
 * @version 1.0.0
 */
class JKOPayPaymentResponse {

	use SingletonTrait;

	/**
	 * Init the instance
	 *
	 * @return void
	 */
	public static function init() {
		self::get_instance();

		// Payment listener/API hook.
		add_action( 'woocommerce_api_jkopay_result', array( self::get_instance(), 'order_notify_response' ) );
		add_action( 'woocommerce_api_jkopay_confirm', array( self::get_instance(), 'jkopay_order_confirm' ) );

		// result_display_url 消費者授權同意後，消費者會被導向的平台客戶端結果網頁。
		add_action( 'woocommerce_api_jkopay_authpay_result_display', array( self::get_instance(), 'authpay_result_display' ) );
		
		// 3.2.1授權成功確認(AuthPay_Result_Url)
		add_action( 'woocommerce_api_jkopay_authpay_result', array( self::get_instance(), 'authpay_result_url_response' ) );

		// 3.6. 街口通知平台授權終止
		add_action( 'woocommerce_api_jkopay_authpay_notify', array( self::get_instance(), 'subscription_authpay_notify' ) );

	}

	/**
	 * Receive payment notify result data from JKOPay.
	 * JKOPay -> WooCommerce 通知交易結果
	 *
	 * @return void
	 */
	public function order_notify_response() {
		global $woocommerce;

		$json = file_get_contents( 'php://input' );

		// Takes raw data from the request
		JKOPayPayment::log( 'norify_url called=====>' );
		JKOPayPayment::log( wc_print_r( $json, true ) );

		$notify_response = json_decode( $json, true );

		JKOPayPayment::log( 'Order ' . $notify_response['transaction']['platform_order_id'] . ' notification received: ' . wc_print_r( $notify_response['transaction'], true ) );

		$platform_order_id   = $notify_response['transaction']['platform_order_id'];
		$status     = (string) $notify_response['transaction']['status'];
		$trade_no   = $notify_response['transaction']['tradeNo'];
		$trans_time = $notify_response['transaction']['trans_time'];

		JKOPayPayment::log( 'platform_order_id:' . $platform_order_id . ' status:' . $status . ' trade_no:' . $trade_no );

		$order_id = self::get_order_by_platform_order_id( $platform_order_id );

		$order = wc_get_order( $order_id );
		if ( $order ) {

			$order->update_meta_data( OrderMeta::TRADE_NO, $trade_no );
			$order->update_meta_data( OrderMeta::STATUS, $status );
			$order->update_meta_data( OrderMeta::TRANS_TIME, $trans_time );

			$api_relay  = ( get_option( 'jkopay_payment_api_relay_enabled' ) === 'yes' ) ? __( 'Relay', 'wpbr-jkopay-payment' ) : __( 'Direct', 'wpbr-jkopay-payment' );
			$order->update_meta_data( OrderMeta::REQUEST_MODE, $api_relay );
			
			$order->save();

			if ( '0' === $status ) {
				$order->payment_complete( $trade_no );
			} else {
				$order->update_status( 'on-hold' );
			}
		} else {
			JKOPayPayment::log( 'Order not found: ' . $platform_order_id );
		}

	}

	public function jkopay_order_confirm() {

		$json = file_get_contents( 'php://input' );

		JKOPayPayment::log( 'order confirm called=====>' );
		JKOPayPayment::log( wc_print_r( $json, true ) );

		$confirm_request = json_decode( $json, true );
		$platform_order_id        = $confirm_request['platform_order_id'];
		$order_id = self::get_order_by_platform_order_id( $platform_order_id );

		$order = wc_get_order( $order_id );
		if ( $order ) {
			if ( $order->needs_payment() ) {
				$resp = wp_json_encode( array( 'valid' => true ) );
			} else {
				$resp = wp_json_encode( array( 'valid' => false ) );
			}
		} else {
			$resp = wp_json_encode( array( 'valid' => false ) );
		}

		JKOPayPayment::log( 'JKOPay order_id:' . $order_id . ' confirm response:' . $resp );

		echo $resp;
		die();

	}

	public function authpay_result_display() {

		$order_id = isset( $_GET['order_id'] ) ? sanitize_text_field( $_GET['order_id'] ) : '';
		$order = wc_get_order( $order_id );
		if ( $order ) {
			$redurect_url = JKOPayPaymentRequest::get_return_url( $order );
			wp_redirect( $redurect_url );
			exit;
		}

	}
	/**
	 * 3.2.1授權成功確認(AuthPay_Result_Url)
	 */
	public function authpay_result_url_response() {
		$json = file_get_contents( 'php://input' );

		JKOPayPayment::log( 'authpay result url called=====>' );
		JKOPayPayment::log( wc_print_r( $json, true ) );

		//  {
		//    "authpay":{
		//      "type":"limited",
		//      "auth_no":"7307529850347089920",
		//      "status":"granted",
		//     "platform_authpay_id":"WPBR2491",
		//     "jkos_account":"900433155",
		//     "billing_currency":""
		//     }
		//  }

		$auth_response       = json_decode( $json, true );
		$auth_no             = $auth_response['authpay']['auth_no']; //街口端授權編號
		$status              = $auth_response['authpay']['status'];
		$platform_authpay_id = $auth_response['authpay']['platform_authpay_id'];
		$jkos_account        = $auth_response['authpay']['jkos_account'];
		$billing_currency    = $auth_response['authpay']['billing_currency'];

		$order_id = self::get_order_by_platform_order_id( $platform_authpay_id );
		$order = wc_get_order( $order_id );
		if ( $order ) {
			$order->update_meta_data( OrderMeta::AUTH_NO, $auth_no );
			$order->update_meta_data( OrderMeta::AUTH_STATUS, $status );
			$order->save();

			// get the subscription order and update the auth_no and auth_status
			$subscription_order = null;
			if ( function_exists('wcs_order_contains_subscription') && wcs_order_contains_subscription( $order->get_id() ) ) {
				$subscriptions = wcs_get_subscriptions_for_order( $order_id );
				foreach ( $subscriptions as $subscription ) {
					$subscription_order = $subscription;
					break;
				}
			}
			if ( $subscription_order ) {
				$subscription_order->update_meta_data( OrderMeta::AUTH_NO, $auth_no );
				$subscription_order->update_meta_data( OrderMeta::AUTH_STATUS, $status );
				$subscription_order->save();
			}

			if ( $order->get_total() > 0 ) {
				JKOPayPayment::log( 'order needs payment...');
				//do authpay_payment
				$request = new JKOPayPaymentRequest( new JKOPayPaymentSubscription() );
				try {
					$result = $request->authpay_request( $order );
					JKOPayPayment::log( 'authpay_transaction result:' . wc_print_r( $result, true ) );
					if ( $result->result === '000' ) {
						$order->payment_complete( $result->result_object->tradeNo );
						$order->update_meta_data( OrderMeta::TRADE_NO, $result->result_object->tradeNo );
						$order->update_meta_data( OrderMeta::STATUS, $result->result_object->status );
						$order->update_meta_data( OrderMeta::TRANS_TIME, $result->result_object->trans_time );
						$order->update_meta_data( OrderMeta::PLATFORM_ORDER_ID, $result->result_object->platform_order_id );
						$order->save();
					}
				} catch ( \Exception $e ) {
					JKOPayPayment::log( 'authpay_transaction error: ' . $e->getMessage() );
				}
			} else {
				$order->payment_complete( $auth_no );
			}

			
		} else {
			JKOPayPayment::log( 'Order not found: ' . $order_id );
		}
		
	}

	public function subscription_authpay_notify() {
		$json = file_get_contents( 'php://input' );

		JKOPayPayment::log( 'subscription authpay notify called=====>' );
		JKOPayPayment::log( wc_print_r( $json, true ) );
		//{"platform_authpay_id": "WPBR2644", "auth_no": "7313657671322816512", "cancel_time": "2025-04-04 04:26:00"}
		$authpay_response = json_decode( $json, true );
		$platform_authpay_id = $authpay_response['platform_authpay_id'];
		$auth_no = $authpay_response['auth_no'];
		$cancel_time = $authpay_response['cancel_time'];

		$order_id = self::get_order_by_platform_order_id( $platform_authpay_id );
		$order = wc_get_order( $order_id );
		if ( $order ) {
			$order->add_order_note( sprintf( __( 'Jkopay auth pay canceled. auth_no: %s, cancel_time: %s', 'wpbr-jkopay-payment' ), $auth_no, $cancel_time ) );
			$order->update_meta_data( OrderMeta::AUTH_STATUS, 'canceled' );
			$order->save();

			//get subscription order and update the auth_status
			$subscription_order = null;
			if ( function_exists('wcs_order_contains_subscription') && wcs_order_contains_subscription( $order->get_id() ) ) {
				$subscriptions = wcs_get_subscriptions_for_order( $order_id );
				foreach ( $subscriptions as $subscription ) {
					$subscription_order = $subscription;
					break;
				}
			}

			if ( $subscription_order ) {
				$subscription_order->add_order_note( sprintf( __( 'Jkopay auth pay canceled. auth_no: %s, cancel_time: %s', 'wpbr-jkopay-payment' ), $auth_no, $cancel_time ) );
				$subscription_order->update_meta_data( OrderMeta::AUTH_STATUS, 'canceled' );
				$subscription_order->save();
			}
		}
		
		
	}

	public static function get_order_by_platform_order_id( $platform_order_id ) {
		//query order by meta _jkopay_platform_order_id
		$orders = wc_get_orders( array(
			'meta_key'   => '_jkopay_platform_order_id',
			'meta_value' => $platform_order_id,
		) );
		if ( $orders ) {
			return $orders[0]->get_id();
		} else {
			return $platform_order_id;
		}
	}

}
