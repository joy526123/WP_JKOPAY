<?php

namespace WPBrewer\JKOPay\Payment\Gateways;

use WPBrewer\JKOPay\Payment\JKOPayPayment;

/**
 * JKOPay Order Status class
 *
 * @package jkopay
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * JKOPay Order Status
 *
 * @class JKOPayOrderStatus
 *
 * @version 1.0.0
 */
class JKOPayOrderStatus {

	/**
	 * The payment gateway instance.
	 *
	 * @var JKOPayPayment
	 */
	private $gateway;

	/**
	 * Constructor.
	 *
	 * @param JKOPayPayment $gateway The payment gateway instance.
	 */
	public function __construct( $gateway ) {
		$this->gateway = $gateway;
	}

	const SUCCESS    = '0';
	const PROCESSING = '1';
	const UNPAID     = '101';
	const NOTFOUND   = '05';

	/**
	 * Get order status description by status number
	 *
	 * @param string $status_code The order status code.
	 * @return string
	 */
	public static function get_desc( $status_code ) {
		$status_desc = '';
		switch ( $status_code ) {
			case '0':
				$status_desc = __( 'Transaction success', 'wpbr-jkopay-payment' );
				break;
			case '1':
				$status_desc  = __( 'Processing payment', 'wpbr-jkopay-payment' );
				break;
			case '101':
				$status_desc = __( 'Order has not been paid', 'wpbr-jkopay-payment' );
				break;
			case '102':
				$status_desc = __( 'Order number does not exist', 'wpbr-jkopay-payment' );
				break;
		}
		return $status_desc;
	}

}
