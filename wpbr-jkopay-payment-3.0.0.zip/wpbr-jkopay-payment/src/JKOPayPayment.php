<?php

namespace WPBrewer\JKOPay\Payment;

use WPBrewer\JKOPay\Payment\Admin\JKOPayOrderMetaBoxes;
use WPBrewer\JKOPay\Payment\Gateways\JKOPayPaymentResponse;
use WPBrewer\JKOPay\Payment\Gateways\JKOPayPaymentSubscriptionsHandler;
use WPBrewer\JKOPay\Payment\Settings\JKOPayPaymentSettingsTab;
use WPBrewer\JKOPay\Payment\Utils\SingletonTrait;

/**
 * JKOPay_Payment class file
 *
 * @package jkopay
 */

defined( 'ABSPATH' ) || exit;

/**
 * JKOPay_Payment main class for handling all checkout related process.
 */
class JKOPayPayment {

	use SingletonTrait;

	/**
	 * Whether or not logging is enabled.
	 *
	 * @var boolean
	 */
	public static $log_enabled = false;

	/**
	 * WC_Logger instance.
	 *
	 * @var WC_Logger Logger instance
	 * */
	public static $log = false;

	/**
	 * If the payment is in test mode.
	 *
	 * @var boolean
	 */
	public static $testmode = false;

	/**
	 * Suppoeted payment gateways
	 *
	 * @var array
	 * */
	public static $allowed_payments;

	/**
	 * Whether or not API relay is enabled.
	 *
	 * @var boolean
	 */
	public static $api_relay_enabled;

	/**
	 * Initialize class and add hooks
	 *
	 * @return void
	 */
	public static function init() {

		self::get_instance();

		add_action( 'after_setup_theme', array( self::get_instance(), 'plugin_i18n' ), 10 );
		add_action( 'woocommerce_init', array( self::get_instance(), 'plugin_init' ), 10 );

		add_filter( 'plugin_action_links_' . JKOPAY_BASENAME, array( self::get_instance(), 'jkopay_add_action_links' ) );
		add_filter( 'woocommerce_get_settings_pages', array( self::get_instance(), 'jkopay_add_settings' ), 10 );
		add_filter( 'woocommerce_payment_gateways', array( self::get_instance(), 'add_jkopay_payment_gateway' ) );
		add_filter( 'woocommerce_gateway_title', array( self::get_instance(), 'jkopay_change_payment_gateway_title_on_test_mode' ), 100, 2 );
		add_action( 'woocommerce_admin_field_store_id', array( self::get_instance(), 'jkopay_store_id_field' ) );
		add_action( 'woocommerce_admin_field_order_prefix', array( self::get_instance(), 'jkopay_order_prefix_field' ) );

		add_action( 'wp_ajax_jkopay_verify_store_id', array( self::get_instance(), 'jkopay_verify_store_id' ) );

		//force curl to use ipv4
		add_action('http_api_curl', function( $handle, $r, $url ) {
			curl_setopt( $handle, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4 );
		 }, 10, 3);

		//enqueue admin styles
		add_action( 'admin_enqueue_scripts', array( self::get_instance(), 'jkopay_enqueue_admin_styles' ) );

	}

	public function plugin_i18n() {
		load_plugin_textdomain( 'wpbr-jkopay-payment', false, dirname( JKOPAY_BASENAME ) . '/languages' );
	}

	public function plugin_init() {
		self::$log_enabled       = 'yes' === get_option( 'jkopay_payment_debug_log_enabled', 'no' );
		self::$testmode          = 'yes' === get_option( 'jkopay_payment_testmode_enabled' );
		self::$api_relay_enabled = 'yes' === get_option( 'jkopay_payment_api_relay_enabled' );

		JKOPayOrderMetaBoxes::init();
		JKOPayPaymentResponse::init();
		JKOPayPaymentSubscriptionsHandler::init();

		self::$allowed_payments = array(
			'jkopay-payment-onetime' => 'WPBrewer\JKOPay\Payment\Gateways\JKOPayPaymentOnetime',
			'jkopay-payment-subscription' => 'WPBrewer\JKOPay\Payment\Gateways\JKOPayPaymentSubscription',
		);
	}

	public function jkopay_store_id_field() {
		?>
		<tr valign="top" id="jkopay-storeid-row">
        <th scope="row" class="titledesc">
            <label>Store ID</label>
        </th>
		<td class="forminp forminp-text">
            <fieldset>
			<input type="text" class="input-text" name="jkopay_payment_storeid" required value="<?php echo esc_html( get_option( 'jkopay_payment_storeid' ) ); ?>"><button class="button" id="jkopay-storeid-verify-btn">驗證</button>
			</fieldset>
		</td>
	 

	 <?php
	}

	public function jkopay_order_prefix_field() {
		$order_prefix_verified = ( wc_string_to_bool( get_option( 'jkopay_payment_order_prefix_verified' ) ) ) ? 'yes' : 'no';
		$order_prefix_verify_status = ( wc_string_to_bool( $order_prefix_verified ) ) ? '已驗證' : '未驗證';
		$readonly = ( wc_string_to_bool( $order_prefix_verified ) ) ? 'readonly' : '';
		?>
		<tr valign="top" id="jkopay-order-prefix-row">
			<th scope="row" class="titledesc">
				<label><?php _e( 'Platform Order Prefix', 'wpbr-jkopay-payment' ); ?></label>
			</th>
			<td class="forminp forminp-text">
				<fieldset>
					<input type="text" class="input-text" name="jkopay_payment_order_prefix" minlength="2" maxlength="4" required value="<?php echo esc_html( get_option( 'jkopay_payment_order_prefix' ) ); ?>" <?php echo esc_html( $readonly ); ?>><span class="order_prefix_verify_status status-<?php echo esc_html( $order_prefix_verified ); ?>"><?php echo esc_html( $order_prefix_verify_status ); ?></span>
				</fieldset>
				<span class="order_prefix_verify_status_description">為避免訂單編號重複，請輸入2~4個字元訂單前綴，僅可包含英文、數字、底線(_)和破折號(-)，需以英文字母開頭且不區分大小寫。<br/>輸入完成後請驗證 Store ID，驗證成功後無法自行修改。此平台訂單前綴不會影響網站訂單編號顯示。</span>
			</td>
		</tr>
		<?php
	}
	

	public function jkopay_verify_store_id() {

		$posted = wp_unslash( $_POST );

		if ( ! array_key_exists( 'security', $posted ) || ! wp_verify_nonce( $posted['security'], 'jkopay-storeid' ) ) {
			$return = array(
				'success' => false,
				'message' => __( 'Unsecure AJAX call', 'wpbr-jkopay-payment' ),
			);
			wp_send_json( $return );
		}

		$store_id     = $posted['store_id'];
		$order_prefix = $posted['order_prefix'];

		$request_body = array(
			'store_id'     => $store_id,
			'order_prefix' => $order_prefix,
			'store_weburl' => home_url('/'),
		);
		JKOPayPayment::log( 'verify store id request: ' . wc_print_r( $request_body, true ) );
		
		$response = wp_remote_post( 'https://wpbrewer.com/wp-json/jkopay/v1/verify', array(
			'method'      => 'POST',
			'User-Agent'  => 'JKOPay-WooCommerce-Plugin-Verify-Store-ID',
			'body'        => $request_body,
			// 'headers'     => array(
			// 	'Content-Type' => 'application/json'
			// ),
		) );
		JKOPayPayment::log( 'verify store id response: ' . wc_print_r( $response, true ) );
		if ( ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200 ) {
			$body = wp_remote_retrieve_body( $response );
			$data = json_decode( $body, true );
			JKOPayPayment::log( 'verify store id response: ' . wc_print_r( $data, true ) );
			
			$api_key      = $data['api_key'];
			$secret_key   = $data['secret_key'];
			$order_prefix = $data['order_prefix'];
			
			update_option( 'jkopay_payment_storeid', $store_id );
			update_option( 'jkopay_payment_order_prefix', $order_prefix );
			update_option( 'jkopay_payment_order_prefix_verified', 'yes' );
			update_option( 'jkopay_payment_api_key', $api_key );
			update_option( 'jkopay_payment_secret_key', $secret_key );
			update_option( 'jkopay_payment_store_verified_at', $data['verified_at'] );
			// if ( $data['success'] ) {
				$return = array(
					'success' => true,
					'message' => __( 'Store ID is valid', 'wpbr-jkopay-payment' ),
				);
				wp_send_json( $return );
			// }
		} else {
			if ( is_wp_error( $response ) ) {
				$message = $response->get_error_message();
			} else {
				$body = wp_remote_retrieve_body( $response );
				$data = json_decode( $body, true );
				$message = $data['message'];
			}
			update_option( 'jkopay_payment_order_prefix_verified', 'no' );
			update_option( 'jkopay_payment_order_prefix', '' );
			$return = array(
				'success' => false,
				'message' => __( 'Failed to verify store id', 'wpbr-jkopay-payment' ),
				'error' => $message,
			);
			wp_send_json( $return );
		}
	}

	public function jkopay_enqueue_admin_styles() {

		//enqueue js script
		wp_enqueue_script( 'jkopay-admin-script', JKOPAY_PLUGIN_URL . 'assets/js/scripts-admin.js', array( 'jquery' ), time(), true );
		
		wp_localize_script(
			'jkopay-admin-script',
			'jkopay_object',
			array(
				'ajax_url'             => admin_url( 'admin-ajax.php' ),
				'original_store_id'    => get_option( 'jkopay_payment_storeid' ),
				'jkopay_storeid_nonce' => wp_create_nonce( 'jkopay-storeid' ),
			)
		);

		// Add admin styles
		wp_enqueue_style(
			'jkopay-admin-style',
			JKOPAY_PLUGIN_URL . 'assets/css/styles-admin.css',
			array(),
			time()
		);
	}

	public function jkopay_change_payment_gateway_title_on_test_mode( $title, $payment_id ) {
		$test_mode = wc_string_to_bool( get_option( 'jkopay_payment_testmode_enabled' ) );
		if ( array_key_exists( $payment_id, self::$allowed_payments ) && $test_mode ) {
			   $title = $title . '(' . __( 'Test Mode', 'wpbr-jkopay-payment' ) . ')';
		}
		return $title;
	}

	/**
	 * Plugin action links
	 *
	 * @param array $links action links array.
	 * @return array
	 */
	public function jkopay_add_action_links( $links ) {
		$setting_links = array(
			'<a href="' . admin_url( 'admin.php?page=wc-settings&tab=jkopay' ) . '">' . esc_html__( 'Settings', 'wpbr-jkopay-payment' ) . '</a>',
		);
		return array_merge( $links, $setting_links );
	}

	/**
	 * Add payment gateways
	 *
	 * @param array $methods JKOPay Payment gateways.
	 * @return array
	 */
	public function add_jkopay_payment_gateway( $methods ) {
		$merged_methods = array_merge( $methods, self::$allowed_payments );
		return $merged_methods;
	}

	/**
	 * Add settings tab
	 *
	 * @return array
	 */
	public function jkopay_add_settings( $settings ) {
		if ( is_array( $settings ) ) {
			$settings[] = new JKOPayPaymentSettingsTab();
		} else {
			$other_settings = $settings;
			$settings       = array( new JKOPayPaymentSettingsTab(), $other_settings );
		}

		return $settings;
	}

	/**
	 * Log method.
	 *
	 * @param string $message The message to be logged.
	 * @param string $level The log level. Optional. Default 'info'. Possible values: emergency|alert|critical|error|warning|notice|info|debug.
	 * @return void
	 */
	public static function log( $message, $level = 'info' ) {
		if ( self::$log_enabled ) {
			if ( empty( self::$log ) ) {
				self::$log = new \WC_Logger();
			}
			self::$log->log( $level, $message, array( 'source' => 'wpbr-jkopay-payment' ) );
		}
	}
}
