<?php

namespace WPBrewer\JKOPay\Payment\Utils;

class OrderMeta {

    const PLATFORM_ORDER_ID = '_jkopay_platform_order_id';
    const TRADE_NO          = '_jkopay_trade_no';
    const STATUS            = '_jkopay_status';
    const TRANS_TIME        = '_jkopay_trans_time';
    const REQUEST_MODE      = '_jkopay_request_mode';

    // subscription
    const AUTH_NO           = '_jkopay_auth_no';
    const AUTH_STATUS       = '_jkopay_auth_status';

    // refund
    const REFUND_TRANSACTION_IDS = '_jkopay_refund_transaction_ids';

}