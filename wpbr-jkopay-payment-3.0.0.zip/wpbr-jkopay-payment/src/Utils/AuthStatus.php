<?php

namespace WPBrewer\JKOPay\Payment\Utils;

class AuthStatus {

    const UNGRANTED = 'ungranted';
    const GRANTED   = 'granted';
    const CANCEL    = 'cancel';
}