<?php

namespace WPBrewer\JKOPay\Payment\Settings;

use WPBrewer\JKOPay\Payment\JKOPayPayment;

/**
 * JKOPay Payment Settings Tab class
 *
 * @package jkopay
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * JKOPay Payment Settings Tab
 *
 * @class JKOPayPaymentSettingsTab
 *
 * @version 1.0.0
 */
class JKOPayPaymentSettingsTab extends \WC_Settings_Page {

	/**
	 * Setting constructor.
	 */
	public function __construct() {

		$this->id    = 'jkopay';
		$this->label = __( 'JKOPay', 'wpbr-jkopay-payment' );

		add_action( 'woocommerce_settings_' . $this->id, array( $this, 'output' ) );
		add_action( 'woocommerce_settings_save_' . $this->id, array( $this, 'save' ) );
		add_action( 'woocommerce_sections_' . $this->id, array( $this, 'output_sections' ) );
		add_filter( 'woocommerce_admin_settings_sanitize_option_jkopay_payment_storeid', array( $this, 'sanitize_option_jkopay_payment_storeid' ), 10, 3 );
		add_action( 'woocommerce_update_options', array( $this, 'reset_jkopay_related_options_after_save' ), 10, 1 );

		parent::__construct();
	}

	/**
	 * Get setting sections
	 *
	 * @return array
	 */
	public function get_sections() {

		$sections = array(
			'payment' => __( 'Payment Settings', 'wpbr-jkopay-payment' ),
		);

		return apply_filters( 'woocommerce_get_sections_' . $this->id, $sections );
	}


	/**
	 * Get all the settings for this plugin for @see woocommerce_admin_fields() function.
	 *
	 * @param string $current_section The current section name.
	 * @return array Array of settings for @see woocommerce_admin_fields() function.
	 */
	public function get_settings( $current_section = '' ) {

			$settings = apply_filters(
				'jkopay_payment_settings',
				array(
					array(
						'title' => __( 'General Payment Settings', 'wpbr-jkopay-payment' ),
						'type'  => 'title',
						'id'    => 'payment_general_setting',
					),
					array(
						'title'   => __( 'Debug Log', 'wpbr-jkopay-payment' ),
						'type'    => 'checkbox',
						'default' => 'no',
						'desc'    =>  sprintf( __( 'Log JKOPay Payment message. You Can find logs at WooCommerce -> Status -> Logs with source name "wpbr-jkopay-payment". %s', 'wpbr-jkopay-payment' ), $this->get_log_link() ),
						'id'      => 'jkopay_payment_debug_log_enabled',
					),
					array(
						'title'   => __( 'Display Logo', 'wpbr-jkopay-payment' ),
						'type'    => 'checkbox',
						'default' => 'no',
						'desc'    =>  __( 'Display logo after the payment method title on checkout page', 'wpbr-jkopay-payment' ),
						'id'      => 'jkopay_payment_display_logo_enabled',
					),
					array(
						'title' => __( 'Logo Type', 'wpbr-jkopay-payment' ),
						'type' => 'radio',
						'options' => array(
							'black' => __( 'Black (for light background)', 'wpbr-jkopay-payment' ),
							'white' => __( 'White (for dark background)', 'wpbr-jkopay-payment' ),
						),
						'id' => 'jkopay_payment_logo_type',
						'default' => 'black',
					),
					array(
						'type' => 'sectionend',
						'id'   => 'payment_general_setting',
					),
					array(
						'title' => __( 'API Settings', 'wpbr-jkopay-payment' ),
						'type'  => 'title',
						'desc'  => __( 'Enter your JKOPay API credentials', 'wpbr-jkopay-payment' ),
						'id'    => 'jkopay_payment_api_settings',
					),
					array(
						'title'   => __( 'Test Mode', 'wpbr-jkopay-payment' ),
						'type'    => 'checkbox',
						'default' => 'yes',
						'desc'    => __( 'When enabled, you need to use the test-only data below.', 'wpbr-jkopay-payment' ),
						'id'      => 'jkopay_payment_testmode_enabled',
					),
					array(
						'title' => __( 'Platform Order Prefix', 'wpbr-jkopay-payment' ),
						'type' => 'order_prefix',
						'id' => 'jkopay_payment_order_prefix',
					),
					array(
						'title'    => __( 'Store ID', 'wpbr-jkopay-payment' ),
						'type'     => 'store_id',
						'desc'     => __( 'This is the StoreID when you apply JKOPay payment', 'wpbr-jkopay-payment' ),
						'desc_tip' => true,
						'id'       => 'jkopay_payment_storeid',
					),
					array(
						'title'    => __( 'API Key', 'wpbr-jkopay-payment' ),
						'type'     => 'text',
						'desc'     => __( 'This is the API Key when you apply JKOPay payment', 'wpbr-jkopay-payment' ),
						'desc_tip' => true,
						'custom_attributes' => array(
							'readonly' => 'readonly',
						),
						'id'       => 'jkopay_payment_api_key',
					),
					array(
						'title'    => __( 'Secret Key', 'wpbr-jkopay-payment' ),
						'type'     => 'text',
						'desc'     => __( 'This is the secret key when you apply JKOPay payment', 'wpbr-jkopay-payment' ),
						'desc_tip' => true,
						'custom_attributes' => array(
							'readonly' => 'readonly',
						),
						'id'       => 'jkopay_payment_secret_key',
					),
					array(
						'title'    => __( 'Verified At', 'wpbr-jkopay-payment' ),
						'type'     => 'text',
						'desc'     => __( 'The datetime when verify success', 'wpbr-jkopay-payment' ),
						'desc_tip' => true,
						'custom_attributes' => array(
							'readonly' => 'readonly',
						),
						'id'       => 'jkopay_payment_store_verified_at',
					),
					array(
						'title'    => __( 'Server IPv4', 'wpbr-jkopay-payment' ),
						'type'     => 'text',
						'value'    => $this->get_server_ipv4(),
						'custom_attributes' => array(
							'readonly' => 'readonly',
						),
						'desc' => __( 'Please check if the server IP address is correct and provide to JKOPay. Some sevrer may have mutiple IPv4 addresses.', 'wpbr-jkopay-payment' ),
					),
					// array(
					// 	'title'    => __( 'API Relay (Beta)', 'wpbr-jkopay-payment' ),
					// 	'type'     => 'checkbox',
					// 	'desc'     => __( 'When enabled, the payment will be processed by the WPBrewer API Relay service. Uncheck to call JKOPay API directly (Fixed IP needed).', 'wpbr-jkopay-payment' ),
					// 	'default'  => 'no',
					// 	'id'       => 'jkopay_payment_api_relay_enabled',
					// ),
					array(
						'type' => 'sectionend',
						'id'   => 'jkopay_payment_api_settings',
					),
				)
			);

		return apply_filters( 'woocommerce_get_settings_' . $this->id, $settings, $current_section );
	}


	public function sanitize_option_jkopay_payment_storeid( $value, $option, $raw_value ) {
		JKOPayPayment::log( 'sanitize_option: ' . wc_print_r( $option, true ) . ' = ' . wc_print_r( $value, true ) . ' raw_value: ' . wc_print_r( $raw_value, true ) );
		if ( 'jkopay_payment_storeid' === $option['id'] ) {
			$old_value = get_option( $option['id'] );
			if ( $old_value !== $value ) {

				set_transient( 'reset_jkopay_related_options', true, 10 ); 
        
				JKOPayPayment::log( 'Store ID changed from ' . $old_value . ' to ' . $value . '. Will reset related options after settings are saved.' );
			}
		}
		return $value;
	}

	function reset_jkopay_related_options_after_save( $option ) {
		if ( get_transient( 'reset_jkopay_related_options' ) ) {
			// Only reset related options if the transient flag is set
			JKOPayPayment::log( 'Resetting related options because storeid was changed.' );

			delete_transient( 'reset_jkopay_related_options' ); // Remove flag

			update_option( 'jkopay_payment_order_prefix_verified', '' );
			update_option( 'jkopay_payment_order_prefix', '' );
			update_option( 'jkopay_payment_store_verified_at', '' );
			update_option( 'jkopay_payment_api_key', '' );
			update_option( 'jkopay_payment_secret_key', '' );
		}
	}

	protected function get_log_link() {
        return '<a href="'. esc_url( admin_url( 'admin.php?page=wc-status&tab=logs&source=wpbr-jkopay-payment')). '">' . __( 'View logs', 'wpbr-jkopay-payment' ).'</a>';
    }

	protected function get_server_ipv4() {
		$serverIp = $_SERVER['SERVER_ADDR'];
		if (filter_var($serverIp, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
			return $serverIp;
		} else {
			return "No IPv4 address found";
		}
	}

	/**
	 * Output the setting tab
	 *
	 * @return void
	 */
	public function output() {
		global $current_section;
		$settings = $this->get_settings( $current_section );
		\WC_Admin_Settings::output_fields( $settings );
	}

	/**
	 * Save the settings
	 *
	 * @return void
	 */
	public function save() {
		global $current_section;
		$settings = $this->get_settings( $current_section );
		\WC_Admin_Settings::save_fields( $settings );
	}
}
