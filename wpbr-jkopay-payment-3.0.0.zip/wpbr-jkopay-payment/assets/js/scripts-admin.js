(function($){

    $(document).ready(function(){
      $('#jkopay-storeid-verify-btn').on('click', function(e){
              e.preventDefault();

               // if order prefix is empty, show alert
               var order_prefix = $('input[name="jkopay_payment_order_prefix"]').val();
               if (order_prefix === '') {
                alert('請輸入訂單編號前綴');
                return;
              }
              
              if ($.blockUI) {
                $('#jkopay-storeid-row').block({
                  message: null,
                });
              }

              var store_id     = $('input[name="jkopay_payment_storeid"]').val();
              if ( store_id !== jkopay_object.original_store_id ) {
                alert('Store ID 已變更，請先儲存設定再重新驗證。');
                if ($.blockUI) {
                  $('#jkopay-storeid-row').unblock();
                }
                return;
              }

              $.ajax({
                url: jkopay_object.ajax_url,
                data: {
                  action: 'jkopay_verify_store_id',
                  store_id: store_id,
                  order_prefix: order_prefix,
                  security: jkopay_object.jkopay_storeid_nonce,
                },
                dataType: "json",
                type: 'post',
                success: function (data) {
                  console.log(data);
        
                  if ( data.success ) {
                    alert(data.message);
                  } else {
                    alert( data.message + ': ' + data.error );
                  }

                  if ($.blockUI) {
                    $('#jkopay-storeid-row').unblock();
                  }

                  window.location.reload();
                },
                always: function () {
                  if ($.blockUI) {
                    $('#jkopay-storeid-row').unblock();
                  }
                  window.location.reload();
                }
              });
      });
    });


})(jQuery);
