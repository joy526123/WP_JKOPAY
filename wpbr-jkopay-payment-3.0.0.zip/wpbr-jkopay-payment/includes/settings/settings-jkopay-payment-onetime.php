<?php
/**
 * JKOPay payment settings file
 *
 * @package jkopay
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings for JKOPay Payment Gateway
 */
return array(

	'enabled'     => array(
		'title'   => __( 'Enable/Disable', 'wpbr-jkopay-payment' ),
		'type'    => 'checkbox',
		'label'   => __( 'Enable', 'wpbr-jkopay-payment' ),
		'default' => 'no',
	),
	'title'       => array(
		'title'       => __( 'Title', 'wpbr-jkopay-payment' ),
		'type'        => 'text',
		'description' => __( 'This controls the title which the user sees during checkout.', 'wpbr-jkopay-payment' ),
		'default'     => __( 'JKOPay - Onetime', 'wpbr-jkopay-payment' ),
		'desc_tip'    => true,
	),
	'description' => array(
		'title'       => __( 'Description', 'wpbr-jkopay-payment' ),
		'type'        => 'textarea',
		'description' => __( 'This controls the description which the user sees during checkout.', 'wpbr-jkopay-payment' ),
		'desc_tip'    => true,
	),

);
